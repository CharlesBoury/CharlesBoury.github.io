import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class JNABDP extends PApplet {

PVector origine;

PVector sourisEcran;
PVector sourisMonde;
PVector mouvementSourisEcran;
PVector mouvementSourisMonde;

PVector coinEcranHautGauche;
PVector coinEcranHautDroite;
PVector coinEcranBasGauche;
PVector coinEcranBasDroite;

boolean clic;
boolean drag;
boolean release;
public void mousePressed () { clic    = true; drag = true ;}
public void mouseReleased() { release = true; drag = false;}

boolean toucheOption = false;
boolean toucheLeft   = false;
boolean toucheRight  = false;
boolean toucheUp     = false;
boolean toucheDown   = false;

// on ne peut pas appuyer sur plus de 2 touches en meme temps -_-'
public void keyPressed()  { if (keyCode == SHIFT) { toucheOption  = true ; } 
                     if (keyCode == LEFT ) { toucheLeft    = true ; }
                     if (keyCode == RIGHT) { toucheRight   = true ; }
                     if (keyCode == UP   ) { toucheUp      = true ; }
                     if (keyCode == DOWN ) { toucheDown    = true ; } }
public void keyReleased() { if (keyCode == SHIFT) { toucheOption  = false; } 
                     if (keyCode == LEFT ) { toucheLeft    = false; }
                     if (keyCode == RIGHT) { toucheRight   = false; }
                     if (keyCode == UP   ) { toucheUp      = false; }
                     if (keyCode == DOWN ) { toucheDown    = false; } }


boolean montrerRepere = true;
boolean montrerGrille = false;
boolean montrerSouris = false;
float tailleGrille = 100;
boolean pan = false;

Main main;


public void setup() {
  frameRate(60);
  
  origine = new PVector(width/2, height); // coordonnées ecran
  sourisEcran = new PVector(0, 0);
  sourisMonde = new PVector(0, 0);
  
  main = new Main();
}

public void draw() {
  installerRepereEtCoordonneesSouris();
  background(76,54,45);
  main.update();
  if (montrerSouris) {montrerSourisMonde(15);}
  if (montrerRepere) { montrerRepere(); }
  if (montrerGrille) { montrerGrille(); }
  clic = false;
  release = false;
}






///////////////////////////////////////////////////////
/////////////// fonctions de dessins de base //////////
///////////////////////////////////////////////////////

// tous les y sont inversés. y est positif vers le haut !
public void cercle(PVector a, float r) {
  ellipse(a.x, -a.y, r, r);
}
public void ligne (PVector a, PVector b) {
  line (a.x, -a.y, b.x, -b.y);
}
public void rectangle (PVector basGauche, PVector taille) {
  rect(basGauche.x, -basGauche.y, taille.x, -taille.y);
}
public void courbe (PVector a, PVector b, PVector c, PVector d) {
  bezier(
    a.x, -a.y, 
    b.x, -b.y, 
    c.x, -c.y, 
    d.x, -d.y);
}
public void rotatePivot (PVector pivot, float angle) {
  translate(pivot.x,pivot.y);
  rotate(angle);
  translate(-pivot.x,-pivot.y);
}
public void deRotatePivot (PVector pivot, float angle) {
  translate(pivot.x,pivot.y);
  rotate(-angle);
  translate(-pivot.x,-pivot.y);
}

///////////////////////////////////////////////////////
/////////// fonctions de dessins secondaires //////////
///////////////////////////////////////////////////////

public void ligneHorizontale(float y) {
  ligne(new PVector(limiteEcranGauche(), y), new PVector(limiteEcranDroite(), y));
}

public void ligneVerticale(float x) {
  ligne(new PVector(x, limiteEcranHaut()), new PVector(x, limiteEcranBas()));
}

///////////////////////////////////////////////////////
///////////////// repere et souris ////////////////////
///////////////////////////////////////////////////////

public void installerRepereEtCoordonneesSouris() {

  // sourisEcran
    // le monde n'intervient pas du tout
    PVector ancienneSourisEcran = sourisEcran.copy();
    sourisEcran = new PVector(mouseX, mouseY);
  
    // deplacement de la souris depuis la derniere frame
    mouvementSourisEcran = sourisEcran.copy().sub(ancienneSourisEcran);


  // Monde

    // l'origine bouge si on pan
    if (drag && pan) { origine.add(mouvementSourisEcran); }

    // calcul de la souris du monde suivant l'origine
    sourisMonde =
      sourisEcran.copy()
      .sub(origine)
      .sub(new PVector(1, 3)); // compensation d'un WTF
    // y vers le haut pour tout ce qui est dans le monde
    sourisMonde.y = -sourisMonde.y;

    // la souris du monde bouge pareil que celle de l'ecran
    // car pour l'instant il n'y a pas de zoom
    mouvementSourisMonde = mouvementSourisEcran.copy();
    mouvementSourisMonde.y = -mouvementSourisMonde.y; 
    
    // coins de l'ecran en coordonnées monde
    coinEcranHautGauche = new PVector(limiteEcranGauche(), limiteEcranHaut());
    coinEcranHautDroite = new PVector(limiteEcranDroite(), limiteEcranHaut());
    coinEcranBasGauche  = new PVector(limiteEcranGauche(), limiteEcranBas());
    coinEcranBasDroite  = new PVector(limiteEcranDroite(), limiteEcranBas());



  // On est pret pour dessiner dans notre repere !
  translate(origine.x, origine.y);
}



public float limiteEcranGauche() { return -origine.x      ;}
public float limiteEcranDroite() { return width-origine.x ;}
public float limiteEcranHaut  () { return origine.y       ;}
public float limiteEcranBas   () { return origine.y-height;}


public void montrerRepere() {
  noFill(); stroke(130,117,118,82); strokeWeight(2);
  ligneHorizontale(0);
  ligneVerticale(0);
}

public void montrerGrille() {
  noFill(); stroke(129,121,122,19); strokeWeight(1);

  // lignes verticales
    int lignesADroites = floor(limiteEcranDroite()/tailleGrille);
    if (lignesADroites > 0) {
      for (int i = 1; i <= lignesADroites; i++) {
        ligneVerticale(i*tailleGrille);
      }
    }
    
    int lignesAGauche = floor(limiteEcranGauche()/tailleGrille);
    if (lignesAGauche < 0) {
      lignesAGauche = -lignesAGauche; // mtn c'est positif
      for (int i = 1; i <= lignesAGauche; i++) {
        ligneVerticale(-i*tailleGrille);
      }
    }

  // lignes horizontales
    int lignesEnHaut = floor(limiteEcranHaut()/tailleGrille);
    if (lignesEnHaut > 0) {
      for (int i = 1; i <= lignesEnHaut; i++) {
        ligneHorizontale(i*tailleGrille);
      }
    }
    
    int lignesEnBas = floor(limiteEcranBas()/tailleGrille);
    if (lignesEnBas < 0) {
      lignesEnBas = -lignesEnBas; // mtn c'est positif
      for (int i = 1; i <= lignesEnBas; i++) {
        ligneHorizontale(-i*tailleGrille);
      }
    }

}


public void montrerSourisMonde(float taille) {
  if (drag) { fill(176, 171); noStroke();}
  else      { noFill(); stroke(176, 171); strokeWeight(1);}
  cercle (sourisMonde, taille);
  // deplacement de la souris depuis la derniere frame
  noFill(); stroke(176, 140); strokeWeight(1);
  ligne (sourisMonde, sourisMonde.copy().add(invert(mouvementSourisMonde)));
}



////////////////////////////////////////////////////////////////////////
//////////////////////////fonctions de easing //////////////////////////
////////////////////////////////////////////////////////////////////////
public float easeInOut(float valeurDeBase, float valeurFinale, float t) {
  t = clamp(t, 0, 1);
  float difference = valeurFinale - valeurDeBase;
  float imageDeT = (sin(t*PI-PI/2)+1)/2;
  return valeurDeBase + difference*imageDeT ;
}


public void afficherCourbeEaseInOutPleine(PVector p1, PVector p2, float base){
  
  PVector trajet = p2.copy().sub(p1);
  PVector p1b = p1.copy();
  PVector p2b = p2.copy();

  // cette valeur permet a la fonction
  // bezier de ressembler a easeInOut
  float a = 0.36f;
  p1b.x += trajet.x*a; 
  p2b.x -= trajet.x*a;
  
  // dessin de la courbe
  beginShape();
  vertex(p1.x,-base);
  vertex(p1.x,-p1.y);
  bezierVertex(p1b.x,-p1b.y,p2b.x,-p2b.y,p2.x,-p2.y);
  vertex(p2.x,-base);
  endShape(CLOSE);  
}



////////////////////////////////////////////////////////////////////////
////////////////////////// fonctions maths /////////////////////////////
////////////////////////////////////////////////////////////////////////

public float clamp(float a, float borneMin, float borneMax) {
  return min(max(a, borneMin), borneMax);
}
public float tendreVers(float but, float valeur, float increment){
  increment = abs(increment);
  if (but - valeur > 0) {
    valeur+= increment;
    if ((but - valeur) < 0) {valeur = but; } 
  }
  else if (but - valeur < 0) {
    valeur-= increment;
    if ((but - valeur) > 0) {valeur = but; } 
  }
  return valeur;
}
public static PVector invert(PVector v) {
  return new PVector (-v.x, -v.y);
}
class Circuit {


  PVector[] niveau;
  int nombreDePoints = 19;

  Circuit() {
    niveau = new PVector[19];
    niveau[0]  = new PVector(0.0f, 0.0f);
    niveau[1]  = new PVector(620.0f, 0.0f);
    niveau[2]  = new PVector(1072.0f, 79.0f);
    niveau[3]  = new PVector(1392.0f, 79.0f);
    niveau[4]  = new PVector(1799.0f, 0.0f);
    niveau[5]  = new PVector(2211.0f, 0.0f);
    niveau[6]  = new PVector(2323.0f, 0.0f);
    niveau[7]  = new PVector(2642.0f, -66.0f);
    niveau[8]  = new PVector(2969.0f, -66.0f);
    niveau[9]  = new PVector(3233.0f, 0.0f);
    niveau[10]  = new PVector(3595.0f, 0.0f);
    niveau[11]  = new PVector(3939.0f, -86.0f);
    niveau[12]  = new PVector(4142.0f, -86.0f);
    niveau[13]  = new PVector(4705.0f, 140.0f);
    niveau[14]  = new PVector(5003.0f, -81.0f);
    niveau[15]  = new PVector(5212.0f, -111.0f);
    niveau[16]  = new PVector(5516.0f, 69.0f);
    niveau[17]  = new PVector(5859.0f, 29.0f);
    niveau[18]  = new PVector(6280.0f, 0.0f);
  }


  ///////////////////////////////////////////////////////////////////// 
  public float getForceAtTime(float t) {
    t = t % longueur();
    for (int i = 0; i < niveau.length; i++) {
      if (niveau[i].x > t) {
        float dist = niveau[i].x - niveau[i-1].x;
        float position = t - niveau[i-1].x;
        float pourcentage = position / dist;
        return easeInOut(niveau[i-1].y, niveau[i].y, pourcentage);
      }
    }
    return 0;
  }


  ///////////////////////////////////////////////////////////////////// 
  public float longueur(){
    return niveau[nombreDePoints-1].x;
  }


  ///////////////////////////////////////////////////////////////////// 
  public void display() {
    // affichage
    fill(245, 123, 42, 60); noStroke(); 
    for (int i = 0; i < niveau.length; i++) {
      // on dessine une courbe entre le point et celui d'avant
      if (i!=0) { // sauf pour le premier
        afficherCourbeEaseInOutPleine(niveau[i-1], niveau[i], 0);
      }
    }
    // fin du niveau
    fill(245, 123, 42, 150); stroke(245, 123, 42, 150);
    float tailleDeLaLigneDeFinDeNiveau = 200;
    ligne(new PVector(longueur(), tailleDeLaLigneDeFinDeNiveau/2), new PVector(longueur(),-tailleDeLaLigneDeFinDeNiveau/2));

    
  } 
}
class Main {
  
float time;
Moto moto;
Circuit circuit;

boolean circuitVisible = true;
float force;
float delai;
float forcePlusTard;

float yLigne;
float tailleBornes;

float horizon;
float virage;
float rotondite;
float g;

float largeurRoute;
float aFactor;
float bFactor;

float tourneTete;
float aplat;


Main() {
  moto = new Moto();
  circuit = new Circuit();
}

public void update() {

  // UPDATE
  time += moto.vitesse*2.3f;
  time = time % circuit.longueur();
  
  
  force = circuit.getForceAtTime(time);
  delai = 60;
  if (delai > time) {
    forcePlusTard = force;
  } else {
    forcePlusTard = circuit.getForceAtTime(time-delai);
  }
  
  
  
  yLigne = 50;
  tailleBornes = 22;

  horizon      = 134;
  virage       = -force*2;
  rotondite    = 0;
  g            = 0.22f;

  largeurRoute = 300;
  aFactor      = 0.88f;
  bFactor      = 0.2f;

  tourneTete   = virage/2;
  aplat        = horizon * aFactor;
  

  moto.modifPositionBy(forcePlusTard/200);
  moto.update();



  if (clic){ circuitVisible = !circuitVisible; }

  // DISPLAY

  if (circuitVisible) {displayCircuit();}
  displayRouteBezier();
  displayRoute();
    

  // display force
  //translate(0,-yLigne-horizon);
  //noFill(); stroke(255, 255, 255); strokeWeight(5);
  //ligne(new PVector(0,0),new PVector(-force,0));
  //translate(0,yLigne+horizon);

  // display moto
  translate(0,-yLigne);
  moto.display();
  translate(0,yLigne);
  
}






///////////////////////////////////////////////////////////////////
public void displayRoute(){
  noFill(); stroke(136, 110, 79); strokeWeight(3); strokeCap(SQUARE);
  ligne (
     new PVector(-largeurRoute/2,yLigne), 
     new PVector( largeurRoute/2,yLigne)
  );
  ligne (
     new PVector(-largeurRoute/2,yLigne+tailleBornes/2), 
     new PVector(-largeurRoute/2,yLigne-tailleBornes/2)
  );
  ligne (
     new PVector( largeurRoute/2,yLigne+tailleBornes/2), 
     new PVector( largeurRoute/2,yLigne-tailleBornes/2)
  );
}


public void displayCircuit(){
  float angle = - HALF_PI;
  translate(0,-yLigne-horizon+time);
  rotatePivot (new PVector(0,0), angle);

  circuit.display();  
  // on en dessine un autre pour le moment ou il se termine
  translate(circuit.longueur(),0);
  circuit.display();
  translate(-circuit.longueur(),0);

  rotatePivot (new PVector(0,0), -angle);
  translate(0,yLigne+horizon-time);
}


public void displayRouteBezier(){
  // LA ROUTE BEZIER
  translate(0,-yLigne);

  noFill(); stroke(81, 82, 78); strokeWeight(2);
  ligneHorizontale(horizon);
  
  // 3 points pour le bas de la route 
  PVector basRouteMilieu = new PVector(0,0);
  PVector basRouteGauche = new PVector(-largeurRoute/2,0);
  PVector basRouteDroite = new PVector( largeurRoute/2,0);
  //fill(238,151,27); noStroke();
  //cercle(basRouteMilieu,10);
  //cercle(basRouteGauche,10);
  //cercle(basRouteDroite,10);  
  
  // 3 points pour le haut
  PVector but = new PVector(virage-tourneTete,horizon);
  PVector fuiteRoute = new PVector(-tourneTete*g,horizon);
  PVector batard = new PVector(fuiteRoute.x+(but.x-fuiteRoute.x)*bFactor,horizon+rotondite);
  //fill(232,222,192); noStroke(); cercle(but,10); 
  //fill(235,167,21); noStroke(); cercle(fuiteRoute,10);
  //fill(122,23,155); noStroke(); cercle(batard,7);
  
  // les lignes de fuite de la route, pour les ticons
  //noFill(); stroke(93,84,66);
  //ligne (basRouteMilieu, fuiteRoute);
  //ligne (basRouteGauche, fuiteRoute);  
  //ligne (basRouteDroite, fuiteRoute);

  // 3 points ticons
  PVector ticonMilieu = new PVector(basRouteMilieu.x+ aFactor*(fuiteRoute.x-basRouteMilieu.x),aFactor*horizon);
  PVector ticonGauche = new PVector(basRouteGauche.x+ aFactor*(fuiteRoute.x-basRouteGauche.x),aFactor*horizon);
  PVector ticonDroite = new PVector(basRouteDroite.x+ aFactor*(fuiteRoute.x-basRouteDroite.x),aFactor*horizon);
  //fill(238,151,27); noStroke();
  //cercle(ticonMilieu,5);
  //cercle(ticonGauche,5);
  //cercle(ticonDroite,5);
  
  // la route ! Les beziers
  noFill(); stroke(167,167,136);
  courbe(basRouteMilieu,ticonMilieu,batard,but);
  courbe(basRouteGauche,ticonGauche,batard,but);
  courbe(basRouteDroite,ticonDroite,batard,but);
  
  // display but
  fill(232,222,192); noStroke(); cercle(but,10); 

  translate(0,yLigne);
}



}
class Moto {

float acceleration = 0;
float velocite = 0;
float position = 0;

float vitesse  = 1.6f;
float freinage = 0.015f;
float throttle = 0.002f;

float angle = 0;


/////////////////////////////////////////////////////////////////////
Moto() {}


///////////////////////////////////////////////////////////////////// 
public void update() {
  // INPUT -> modifie ANGLE
    float incrementAngle = 0.03f; // rapidite de mouvement de l'angle
    float angleMax = PI/4;
    if (toucheLeft || toucheRight) {
      if (toucheLeft)  { angle-= incrementAngle ;} 
      if (toucheRight) { angle+= incrementAngle ;}
    } // si pas d'input, l'angle revient a 0
    else {angle = tendreVers(0, angle, incrementAngle); }
    // clamp de l'angle
    angle = clamp(angle, -angleMax, angleMax);
    
    //if (toucheDown) {vitesse -= freinage;} else {vitesse+=throttle;}
    //vitesse = clamp(vitesse, 0, 2);
    //println(vitesse);
  
  // ANGLE -> modifie POSITION
  float friction = 0.21f; // 0 -> glisse. 1 -> immobile
  acceleration = angle * vitesse;
  velocite += acceleration;
  velocite *= (1-friction);
  if (abs(velocite) <= 0.001f) {velocite = 0;}
  position += velocite;
}


///////////////////////////////////////////////////////////////////// 
public void modifPositionBy(float force) {
  position += 9.75f*force; // 9.75 c'est la velocite max
}


///////////////////////////////////////////////////////////////////// 
public void display() {
  int widthMoto = 8;
  int heightMoto = 52;
  fill(255, 255, 255); noStroke();
  rotatePivot(new PVector(position,0), angle);
  rectangle (
    new PVector(position-widthMoto/2, 0),
    new PVector(widthMoto, heightMoto)
  );
  deRotatePivot(new PVector(position,0), angle);
}


}
  public void settings() {  size(500, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "JNABDP" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
